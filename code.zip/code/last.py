import cv2 
import os
from PIL import Image,ImageOps
import numpy as np 
import streamlit as st 
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.layers import TFSMLayer

os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

# Path to the saved TensorFlow model
model_path = "C:\\Users\\Vishal\\OneDrive\\Desktop\\collage project\\unet_model"

# Load the saved model using TensorFlow's native load method
if "loaded_model" not in st.session_state:
    st.session_state.loaded_model = tf.saved_model.load(model_path)
    st.write("Model loaded successfully.")
    st.write(st.session_state.loaded_model.signatures['serving_default'])

# Function to preprocess images
def preprocess(img, check):
    im = Image.open(img)
    image = np.array(im)
    im = im.resize((512, 512))
    if check:
        im_cv = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)
        lab = cv2.cvtColor(im_cv, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        cl = clahe.apply(l)
        limg = cv2.merge((cl, a, b))
        im_cv = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)
        im = Image.fromarray(cv2.cvtColor(im_cv, cv2.COLOR_BGR2RGB))
    return im

# Function to make predictions using the loaded TensorFlow model
def predict_image(model, img_array):
    infer = model.signatures['serving_default']
    input_tensor = tf.convert_to_tensor(img_array, dtype=tf.float32)/ 255.0
    predictions = infer(input_tensor)
    st.write(predictions)
    return predictions['sigmoid'].numpy()[0]  # Adjust based on your model's output tensor name


# Define the Dice coefficient loss function
def dice_coefficient(y_true, y_pred, smooth=1):
    intersection = tf.reduce_sum(y_true * y_pred)
    union = tf.reduce_sum(y_true) + tf.reduce_sum(y_pred)
    return (2. * intersection + smooth) / (union + smooth)


# Set parameters
img_size = 512

# Function to preprocess a single image
def preprocess_image(img_path, img_size):
    img = tf.keras.utils.load_img(img_path, target_size=(img_size, img_size))
    img_array = tf.keras.utils.img_to_array(img, dtype='uint8')
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

# Function to overlay mask on the image with red color
def overlay_mask(image, mask):
    mask_rgb = np.zeros_like(image)
    mask_rgb[:, :, 0] = mask * 255
    alpha = 1.5
    overlay = cv2.addWeighted(image.astype('uint8'), 1, mask_rgb.astype('uint8'), alpha, 0)
    return overlay

# Streamlit app
st.sidebar.markdown("""<center><h1>Human BioMolecular Atlas</h1></center>""", unsafe_allow_html=True)
st.markdown("""<center><h1>Human BioMolecular Atlas</h1><br><h4><i>Artificial Intelligence Powered Tissue Segmentation</h4></i></center>""", unsafe_allow_html=True)

uploadFile = st.sidebar.file_uploader(label="# Upload image", type=["tiff"])

if uploadFile is not None:
    if "pilimag" in st.session_state:
        del st.session_state["pilimag"]
    
    imo = Image.open(uploadFile)
    st.sidebar.image(imo, width=300)
    st.sidebar.markdown(f"Image size:{imo.size}")
    st.session_state.check = st.sidebar.checkbox("Adpative histogram equalizer")
    st.session_state.b1 = st.sidebar.button("Pre-process")
    if st.session_state.b1:
        st.session_state.pilimag = preprocess(uploadFile, st.session_state.check)
    
    c1, c2 = st.columns(2)
    if "pilimag" in st.session_state:
        c1.image(st.session_state.pilimag, width=350, caption="Pre-process image")
        c1.markdown(f"Image size:{st.session_state.pilimag.size}")

        # Preprocess the image and make predictions
        img_array = preprocess_image(uploadFile, img_size)
        mask_pred = predict_image(st.session_state.loaded_model, img_array)
        overlay = overlay_mask(img_array[0], mask_pred[:, :, 0])
        predicted_image = Image.fromarray(overlay)

        c2.image(predicted_image, width=350, caption="Segmented Image")
    
else:
    st.write("Make sure your image is in TIFF format.")
